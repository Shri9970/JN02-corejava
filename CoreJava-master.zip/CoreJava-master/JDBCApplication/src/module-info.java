/**
 * 
 */
/**
 * @author Hp
 *
 */
module JDBCApplication {
	requires java.sql;
	requires org.junit.jupiter.api;
	requires junit;
}