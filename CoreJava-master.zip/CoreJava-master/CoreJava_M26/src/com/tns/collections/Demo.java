package com.tns.collections;

public class Demo {

	public static void main(String[] args) {
		int i;
		for(i=10;i>=1;i--)
			System.out.println(i);
		
			
		
	}

}
