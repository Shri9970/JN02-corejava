package com.tnsif.dayfive.hierarchicalinheritance;

public class HeavyMotorVehicle {

}
