package com.cg.accessspecifier;
public enum Streams { CSE, IT, ENTC, MECH, INSTR,AIDS,CIVIL }