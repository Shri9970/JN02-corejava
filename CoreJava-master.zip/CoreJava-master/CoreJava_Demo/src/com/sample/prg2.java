package com.sample;

public class prg2 {
	public static void main(String args[]) {
		//while loop 
		int i=5;
		while(i<15)
		{
			System.out.print(i+"\t");
			i++;
		}
		
	}

}
