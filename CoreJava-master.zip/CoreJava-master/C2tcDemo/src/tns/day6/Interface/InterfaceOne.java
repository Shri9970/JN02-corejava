package tns.day6.Interface;

public interface InterfaceOne {
	void show();
}
